import './globals.css';
import HomePage from './components/index';
import { Suspense } from 'react';
import RegisterModal from '@shared/layouts/RegisterModal';

export default function Page() {
  return <HomePage />;
}
