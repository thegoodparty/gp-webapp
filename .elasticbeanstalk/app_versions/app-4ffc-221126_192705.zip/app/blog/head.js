import GpHead from '@shared/layouts/GpHead';

export default function Head({ params }) {
  return (
    <GpHead
      title="Blog | Good Party"
      description="Good Party Blog"
      slug="/blog"
    />
  );
}
