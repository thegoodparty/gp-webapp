import GpHead from '@shared/layouts/GpHead';

export default function Head({ params }) {
  return (
    <GpHead
      title="About | GOOD PARTY"
      description="Learn about GOOD PARTY."
      slug="/about"
    />
  );
}
