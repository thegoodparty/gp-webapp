import GpHead from '@shared/layouts/GpHead';

export default function Head({ params }) {
  return (
    <GpHead
      title="Campaign application | GOOD PARTY"
      description="Complete this application to create your campaign on Good Party."
      slug="/campaign-application"
    />
  );
}
