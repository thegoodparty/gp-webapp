'use client';
import TimeAgo from 'react-timeago';

export default function TimeAgoClient({ date }) {
  return <TimeAgo date={date} />;
}
