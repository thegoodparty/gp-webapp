import ApplicationSection from './components/ApplicationSection';
import CampaignStaff from './components/CampaignStaff';

export default function Page() {
  return (
    <>
      <CampaignStaff />
      <ApplicationSection />
    </>
  );
}
