import GpHead from '@shared/layouts/GpHead';

export default function Head({ params }) {
  return (
    <GpHead
      title="GOOD PARTY | Profile Settings"
      slug="/profile/settings"
    />
  );
}
