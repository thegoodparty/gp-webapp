import RunForOfficePage from './components/RunForOfficePage';

export default async function Page(params) {
  return <RunForOfficePage />;
}
