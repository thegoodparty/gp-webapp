import VolunteerPage from './components/VolunteerPage';

export default async function Page(params) {
  return <VolunteerPage />;
}
