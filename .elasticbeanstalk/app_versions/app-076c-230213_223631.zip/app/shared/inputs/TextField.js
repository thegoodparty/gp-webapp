'use client';

import MuiTextField from '@mui/material/TextField';

const TextField = (props) => {
  return <MuiTextField {...props} variant="outlined" />;
};

export default TextField;
