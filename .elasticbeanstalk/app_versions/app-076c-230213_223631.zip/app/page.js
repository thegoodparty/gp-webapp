import './globals.css';
import HomePage from './homepage/HomePage';

export default function Page() {
  return <HomePage />;
}
