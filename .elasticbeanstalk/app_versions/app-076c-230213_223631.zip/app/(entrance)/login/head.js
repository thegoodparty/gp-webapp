import GpHead from '@shared/layouts/GpHead';

export default function Head() {
  return (
    <GpHead
      title="Login | GOOD PARTY"
      description="Login to Good Party."
      slug="/login"
    />
  );
}
