import GpHead from '@shared/layouts/GpHead';

export default function Head() {
  return (
    <GpHead
      title="Register | GOOD PARTY"
      description="Join us at Good Party."
      slug="/register"
    />
  );
}
