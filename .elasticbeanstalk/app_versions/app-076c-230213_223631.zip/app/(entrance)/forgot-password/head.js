import GpHead from '@shared/layouts/GpHead';

export default function Head() {
  return (
    <GpHead
      title="Forgot Password | GOOD PARTY"
      description="Password retrieval for Good Party."
      slug="/forgot-password"
    />
  );
}
