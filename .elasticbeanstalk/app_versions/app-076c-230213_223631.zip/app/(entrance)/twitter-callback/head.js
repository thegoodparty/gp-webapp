import GpHead from '@shared/layouts/GpHead';

export default function Head() {
  return (
    <GpHead
      title="Twitter Login | GOOD PARTY"
      description="Login to Good Party."
      slug="/twitter-callback"
    />
  );
}
