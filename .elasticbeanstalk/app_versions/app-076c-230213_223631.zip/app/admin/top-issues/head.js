import GpHead from '@shared/layouts/GpHead';

export default function Head({ params }) {
  return (
    <GpHead
      title="Top Issues | GOOD PARTY"
      description="Admin Top Issues Dashboard."
      slug="/admin/top-issues"
    />
  );
}
