import GpHead from '@shared/layouts/GpHead';

export default function Head({ params }) {
  return (
    <GpHead
      title="Candidate Portal | GOOD PARTY"
      description="Candidate Portal."
      slug="/onboarding"
    />
  );
}
