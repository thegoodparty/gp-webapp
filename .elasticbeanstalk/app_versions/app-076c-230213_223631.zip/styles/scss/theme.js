import { createTheme } from '@mui/material/styles';
//https://github.com/mui/material-ui/blob/master/examples/nextjs/src/theme.js
const theme = createTheme({});
export default theme;
