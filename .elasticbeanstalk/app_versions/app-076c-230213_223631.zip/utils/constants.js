export const CONTACT_EMAIL = 'ask@goodparty.org';
