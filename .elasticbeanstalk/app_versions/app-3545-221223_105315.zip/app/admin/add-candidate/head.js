import GpHead from '@shared/layouts/GpHead';

export default function Head({ params }) {
  return (
    <GpHead
      title="Admin Candidates | GOOD PARTY"
      description="Admin Candidates Dashboard."
      slug="/admin/candidates"
    />
  );
}
