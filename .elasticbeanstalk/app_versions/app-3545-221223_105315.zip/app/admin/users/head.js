import GpHead from '@shared/layouts/GpHead';

export default function Head({ params }) {
  return (
    <GpHead
      title="Admin Users | GOOD PARTY"
      description="Admin Users Dashboard."
      slug="/admin/users"
    />
  );
}
