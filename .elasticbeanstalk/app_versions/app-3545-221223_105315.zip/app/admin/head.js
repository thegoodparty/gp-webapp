import GpHead from '@shared/layouts/GpHead';

export default function Head({ params }) {
  return (
    <GpHead
      title="Admin Dashboard | GOOD PARTY"
      description="Admin Dashboard."
      slug="/admin"
    />
  );
}
