import './globals.css';
import HomePage from './components/index';

export default function Page() {
  return <HomePage />;
}
