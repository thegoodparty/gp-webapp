import GpHead from '@shared/layouts/GpHead';

export default function Head({ params }) {
  return (
    <GpHead
      title="Profile | GOOD PARTY"
      description="Sign into your profile on GOOD PARTY."
      slug="/profile"
    />
  );
}
