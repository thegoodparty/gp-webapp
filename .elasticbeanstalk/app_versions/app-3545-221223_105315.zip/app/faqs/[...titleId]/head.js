import GpHead from '@shared/layouts/GpHead';

export default function Head({ params }) {
  return (
    <GpHead
      title="FAQs | GOOD PARTY"
      description="Frequently Asked Questions about GOOD PARTY."
      slug="/faqs"
    />
  );
}
