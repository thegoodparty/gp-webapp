import GpHead from '@shared/layouts/GpHead';

export default function Head() {
  return (
    <GpHead
      title="Password Reset | GOOD PARTY"
      description="Password reset for Good Party."
      slug="/reset-password"
    />
  );
}
