import TwitterCallbackPage from './components/twitterCallbackPage';

export default async function Page() {
  return <TwitterCallbackPage />;
}
