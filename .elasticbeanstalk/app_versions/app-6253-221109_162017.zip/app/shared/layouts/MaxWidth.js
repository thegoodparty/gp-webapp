export default function MaxWidth({ children }) {
  return <div className="max-w-screen-xl mx-auto px-4 xl:p-0">{children}</div>;
}
