import DesktopHeader from './DektopHeader';

export default function Nav() {
  return (
    <>
      <div className="md:hidden">mobile</div>
      <DesktopHeader />
    </>
  );
}
