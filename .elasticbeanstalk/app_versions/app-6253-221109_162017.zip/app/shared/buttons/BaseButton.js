'use client';
const BaseButton = ({ children, style }) => {
  return (
    <button className="py-3 px-8 rounded-lg" style={style}>
      {children}
    </button>
  );
};

export default BaseButton;
